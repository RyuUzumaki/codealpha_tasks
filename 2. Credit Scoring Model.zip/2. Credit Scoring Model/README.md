## 📁 Project Structure

```
.github/workflows    # GitHub Actions for CI/CD
api/                 # Backend API components
dashboard/           # Dashboard-related files and slides
notebooks/           # Jupyter notebooks and datasets
scripts/             # Utility or helper scripts
tests/               # Unit and integration test files
.gitignore           # Git ignored files config
README.md            # Project overview and setup guide
requirements.txt     # Required Python packages
```

---

## ⚙️ Installation

### 1. Clone the repository

```bash
git clone https://github.com/epythonlab2/fintech-ml-labs.git
cd fintech-ml-labs
```

### 2. Create and activate a virtual environment

```bash
python -m venv venv
# macOS/Linux
source venv/bin/activate
# Windows
.env\Scriptsctivate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

---

## 🚀 Usage

### Run the Jupyter notebook

Navigate to the `notebooks/` directory and launch Jupyter:

```bash
jupyter notebook
```

Open `credit_scoring_model.ipynb` to explore the machine learning pipeline.
